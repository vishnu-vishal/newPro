package com.newpro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewproApplicationTests {

	@Test
	void contextLoads() {
	}

}
